#!/bin/bash

# 041118 - AWS EC2 BUILD --Version 1.0-- ##
Vers="--Version 1.0--"

#
## SECTION 1: 041118 - Configure SSH to allow root login and enable root password ##

Pass='$6$STakHPnl$OL/Lyf.JDIxD8JVfTDnHgrRlLAqNFRL88Y84zFkWoQ6EquKog27LMrtnIu.wlWbIoZLhsiiA.ue5Y9Q1Cc4CR0'
echo
echo "----------------------BEGIN---------------------------------"
echo "-------------RHEL 7.x AMI BUILD------------------------"
echo
echo "-------------------------------------------"
echo "START :::::::::::: Re-Configuring SSH for Root Login"
echo "-------------------------------------------"
cp /etc/ssh/sshd_config /etc/ssh/sshd_config.orig
sed -i 's/#PermitRootLogin yes/PermitRootLogin yes/' /etc/ssh/sshd_config
sed -i 's/PasswordAuthentication no/PasswordAuthentication yes/' /etc/ssh/sshd_config
service sshd restart
cp /etc/cloud/cloud.cfg /etc/cloud/cloud.cfg.orig
sed -i 's/ssh_pwauth:   0/ssh_pwauth:   1/' /etc/cloud/cloud.cfg
echo "-------------------------------------------"
echo "END ::::::::::::  Re-Configuring SSH for Root Login"
echo "-------------------------------------------"
echo
echo "-------------------------------------------"
echo "START :::::::::::: Register Root Password"
echo "-------------------------------------------"
cp /etc/shadow  /etc/shadow.orig
usermod -p $Pass root
echo "-------------------------------------------"
echo "END ::::::::::::  Register Root Password"
echo "-------------------------------------------"
echo

#
## SECTION 3: 041118 - Install base packages ##

echo "-------------------------------------------"
echo "START :::::::::::: Installing Additional Packages"
echo "-------------------------------------------"
yum -y install bind-utils wget telnet vsftpd lvm2 unzip net-tools net-snmp ntp gcc
echo "-------------------------------------------"
echo "END ::::::::::::  Installing Additional Packages"
echo "-------------------------------------------"
echo

#
## SECTION 5: 041118 - Disable Selinux ##

echo "-------------------------------------------"
echo "START :::::::::::: Disabling SELinux"
echo "-------------------------------------------"
sed -i 's/SELINUX=enforcing/SELINUX=disabled/g' /etc/selinux/config
echo "-------------------------------------------"
echo "END ::::::::::::  Disabling SELinux"
echo "-------------------------------------------"
echo

#
## SECTION 6: 041118 - Add Swap file ##

echo "-------------------------------------------"
echo "START :::::::::::: Adding SWAP File"
echo "-------------------------------------------"
dd if=/dev/zero of=/swapfile bs=1M count=1024
mkswap /swapfile
chmod 600 /swapfile
swapon /swapfile
cp /etc/fstab /etc/fstab.noswap
echo "/swapfile swap swap defaults 0 0" >> /etc/fstab
echo "-------------------------------------------"
echo "END :::::::::::: Adding SWAP File"
echo "-------------------------------------------"
echo
echo "-------------------------------------------"

#
## SECTION 7: 041118 - Enable Cron for root ##

echo "START :::::::::::: Enabling crond for root only"
echo "-------------------------------------------"
touch /etc/cron.allow
rm -f /etc/cron.deny
echo "root" > /etc/cron.allow
systemctl start crond
echo "-------------------------------------------"
echo "END :::::::::::: Enabling crond for root only"
echo "-------------------------------------------"
echo

#
## SECTION 8: 041118 - Create Home Directory ##

echo "-------------------------------------------"
echo "START :::::::::::: Create Home Directory"
echo "-------------------------------------------"
mkdir -p /export/home
echo "-------------------------------------------"
echo "END :::::::::::::  Create Home Directory"
echo "-------------------------------------------"
echo

#
## SECTION 9: 041118 - Perform Patch update ##

echo "-------------------------------------------"
echo "START :::::::::::: Performing Patch Upgrade"
echo "-------------------------------------------"
yum -y update
echo "-------------------------------------------"
echo "END ::::::::::::  Performing Patch Upgrade"
echo "-------------------------------------------"
echo "----------------------END------------------"

#
## SECTION 10: 051618 - Add Timeout to Bash logging
echo "-------------------------------------------"
echo "START :::::::::::: Adding Timeout to shell Profile"
echo "-------------------------------------------"
cp ~/.bashrc ~/.bashrc.orig
echo "# Timeout variable set to 10 minutes" >> /root/.bashrc
echo "TMOUT=600" >> /root/.bashrc
echo "-------------------------------------------"
echo "END ::::::::::::  Timeout Added"
echo "-------------------------------------------"
echo "----------------------END------------------"

#
## SECTION 11: 051818 - Disable IPv6
echo "-------------------------------------------"
echo "START :::::::::::: Disabling IPv6"
echo "-------------------------------------------"
cp /etc/sysctl.conf /etc/sysctl.conf.orig
echo "net.ipv6.conf.all.disable_ipv6 = 1" >> /etc/sysctl.conf
echo "net.ipv6.conf.default.disable_ipv6 = 1" >> /etc/sysctl.conf
echo "net.ipv6.conf.lo.disable_ipv6 = 1" >> /etc/sysctl.conf
echo "-------------------------------------------"
echo "END ::::::::::::  Disabling IPv6 Completed"
echo "-------------------------------------------"
echo "----------------------END------------------"

#
## SECTION 12: 051818 - Set Timezone to Pacific Central And Start NTP Daemon ##
echo "-------------------------------------------"
echo "START :::::::::::: Setting time to PST"
echo "-------------------------------------------"
cp /etc/localtime /etc/localtime.orig
rm -rf /etc/localtime
ln -s /usr/share/zoneinfo/PST8PDT /etc/localtime
sed -i 's/server 0.rhel.pool.ntp.org iburst/#server 0.rhel.pool.ntp.org/' /etc/ntp.conf
sed -i 's/server 1.rhel.pool.ntp.org iburst/#server 1.rhel.pool.ntp.org/' /etc/ntp.conf
sed -i 's/server 2.rhel.pool.ntp.org iburst/#server 2.rhel.pool.ntp.org/' /etc/ntp.conf
sed -i 's/server 3.rhel.pool.ntp.org iburst/#server 3.rhel.pool.ntp.org/' /etc/ntp.conf
systemctl enable ntpd
systemctl start ntpd
echo "-------------------------------------------"
echo "END :::::::::::: Time set completed And NTP Started "
echo "-------------------------------------------"
echo "----------------------END------------------"

#
## SECTION 13: 051818 - Enable log Rotation ##
echo "-------------------------------------------"
echo "START :::::::::::: Enable log Rotation for 3 weeks"
echo "-------------------------------------------"
cp /etc/logrotate.d/syslog /etc/logrotate.d/syslog.orig
sed -i '/    sharedscripts/a    rotate=3' /etc/logrotate.d/syslog
echo "-------------------------------------------"
echo "END :::::::::::: Log Rotation added "
echo "-------------------------------------------"
echo "----------------------END------------------"

#
## SECTION 14: 041218 - Write Script version and date to hidden file ##
echo "-------------------------------------------"
echo "START :::::::::::: Writing Script Version"
echo "-------------------------------------------"
echo "Configuration of build script completed" > /root/.build_script
echo "$Vers installed on `date`" >> /root/.build_script
echo "-------------------------------------------"
echo "END ::::::::::::  Script Version written"
echo "-------------------------------------------"
echo "----------------------END------------------"


###############################################
echo "Place holder for cron,  User logging history,"
###############################################
