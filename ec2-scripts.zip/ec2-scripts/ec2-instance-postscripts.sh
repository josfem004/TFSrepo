#!/bin/bash

## Post Script for AWS PROD environment
set -x
exec > >(tee /root/instance-post.log|logger -t instance-post ) 2>&1


# Variables defined

hostname=`hostname`
dc=`echo $hostname|cut -c1-4`
environment=`echo $hostname|cut -c6`

# Zone Variable: Create default zone. Create /public_cloud/default
zone="tfs.toyota.com/Unix/Zones/Universal/public_cloud/default"
# ad_server Variable: AWS Domain Controller/DNS Server
ad_server=awva-pcwad00993.tfs.toyota.com

# DNE S3 Repository
if [[ $dc = "awoh" ]]
then
    repo="s3://tfs-dne-repo-subprod/tfsrepo/linux/software/agents"
elif [[ $dc = "awva" ]]
then   
    repo="s3://tfs-dne-repo/tfsrepo/linux/software/agents"
fi

echo
echo "----------------------BEGIN---------------------------------"
echo "-------------AWS Post Script Configuration------------------------"
echo

#
## SECTION 1: 041218 - Install Centrify Agent and Join server to AD  ##

echo "-------------------------------------------"
echo "START :::::::::::: Installing Centrify agent  "
echo "-------------------------------------------"

/usr/local/bin/aws s3 cp $repo/centrify/centrifydc-5.3.1-rhel4-x86_64.rpm /tmp/
rpm -ivh /tmp/centrifydc-5.3.1-rhel4-x86_64.rpm
echo "Centrify Version `adinfo -v` is installed"

if [[ -f /usr/bin/adinfo ]]; then 
	
	/usr/sbin/adjoin --force -c "OU=UNIX Servers,OU=Unix" -z $zone -u srv_unix_adjoin -p "Cen7r!fy" tfs.toyota.com --server  $ad_server --verbose

fi

#
# Remove sudo package and relink /usr/bin/sudo binary to /usr/bin/dzdo

if [[ `/usr/bin/adinfo|grep "^CentrifyDC" |awk '{print $NF}'` = "connected" ]] ; then
	yum -y erase sudo
	ln -s /usr/bin/dzdo /usr/bin/sudo
fi
echo "-------------------------------------------"
echo "END ::::::::::::  Installing Centrify agent "
echo "-------------------------------------------"
echo

#
## SECTION 2: 041218 - Install HPOV Agent

echo "-------------------------------------------"
echo "START :::::::::::: Installing HPOV agent  "
echo "-------------------------------------------"

# HPOV Server based on environment
#if [[ $environment = "p" ]]
#then
#    hpov_server="xpvlap0128.tfs.toyota.com"
#else    
#    hpov_server="davlap1783.tfs.toyota.com"
#fi

hpov_server="xpvlap0128.tfs.toyota.com"
tmpdir=/tmp/hpov-install

mkdir -p $tmpdir
/usr/local/bin/aws s3 cp $repo/hpov/hpov-agent-05.tar.gz $tmpdir
cd $tmpdir
tar -xf hpov-agent-05.tar.gz
cd packages/LIN/Linux2.6_X64
chmod +x oasetup.sh
./oasetup.sh -install -management_server $hpov_server -certificate_server $hpov_server -minprecheck
/opt/OV/bin/oalicense -set -type PERMANENT "Glance Software LTU"
/opt/OV/bin/ovcert -certreq

/opt/OV/bin/opcagt -status

echo  "Version installed is `/opt/OV/bin/opcagt -version`"

echo "----------------------------------------------------------------------------------"
echo " Installation of HPOV Agent complete"
echo "----------------------------------------------------------------------------------"

#
## SECTION 3:041118 - Install Chef agent ##

echo "-------------------------------------------"
echo "START :::::::::::: Installing chef agent  "
echo "-------------------------------------------"
/usr/local/bin/aws s3 cp $repo/chef/chef-13.6.0-1.el7.x86_64.rpm /tmp
yum install -y /tmp/chef-13.6.0-1.el7.x86_64.rpm
echo "-------------------------------------------"
echo "END ::::::::::::  Installing chef agent "
echo "-------------------------------------------"
echo

#
## SECTION 4: 041218 - Install Qualys Cloud Agent

echo "START :::: Installing Qualys Cloud Agent"
echo "-------------------------------------------"
/usr/local/bin/aws s3 cp $repo/qualys/qualys-cloud-agent.x86_64.rpm /tmp
yum install -y /tmp/qualys-cloud-agent.x86_64.rpm
/usr/local/qualys/cloud-agent/bin/qualys-cloud-agent.sh ActivationId=a410fa3c-0d25-4e9f-a65e-52554a1a37c7 CustomerId=b77372be-ce61-416f-83f5-de0405ab1bf1
systemctl status qualys-cloud-agent.service
echo "-------------------------------------------"
echo "END ::::  Qualys Cloud Agent"
echo "-------------------------------------------"

#
## SECTION 5: 041218 - Creating Application filesystem
echo "-------------------------------------------"
echo " START :::: Creating Application Filesystem "
echo "-------------------------------------------"

# Picking the second disk assuming only one disk is added part of cft
appdisk=`lsblk -ar|grep disk|head -2|tail -1|awk {'print $1'}`

if [ -e /dev/$appdisk ]
then
   echo -e "n\np\n1\n\n\nw" | fdisk /dev/$appdisk
   partprobe
   part=`lsblk -ar|grep part|grep ^$appdisk|head -1|awk {'print $1'}`
   pv="/dev/$part"
   pvcreate $pv && vgcreate app_vg $pv
   lvcreate -l 100%FREE -n app_vol_001 app_vg
   mkfs.xfs /dev/app_vg/app_vol_001
   echo "/dev/app_vg/app_vol_001     /opt/local      xfs     defaults        0 0" >> /etc/fstab
   mkdir -p /opt/local && mount -a
   mkdir -p /opt/local/home
   mount --rbind /opt/local/home /export/home
   echo "/opt/local/home /export/home none defaults,bind 0 0" >> /etc/fstab
else
   echo Application disk does not exist
fi
echo "-------------------------------------------"
echo " END :::: Application Filesystem created   "
echo "-------------------------------------------"

#
## SECTION 6: 091818 - Install McAfee AntiVirus

echo "-------------------------------------------"
echo "START :::::::::::: Installing McAfee AV    "
echo "-------------------------------------------"

/usr/local/bin/aws s3 cp $repo/McAfee/install.sh /tmp
chmod +x /tmp/install.sh
/tmp/install.sh -i

echo "-------------------------------------------"
echo " END :::::::::::: Completed Installing AV  "
echo "-------------------------------------------"

echo "-------------------------------------------"
echo " START :::: Performing yum install, update and reboot"
echo "-------------------------------------------"

yum install -y rsyslog-gnutls # Needed to complete tls-syslog to SIEM configuration
yum -y update
shutdown -r now

echo "-------------------------------------------"
echo " END :::: yum update and reboot completed  "
echo "-------------------------------------------"

